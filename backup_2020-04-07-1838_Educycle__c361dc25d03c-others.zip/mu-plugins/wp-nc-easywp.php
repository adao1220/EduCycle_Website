<?php
/**
 * Plugin Name: EasyWP Plugin
 * Plugin URI: https://www.namecheap.com/support/knowledgebase/article.aspx/10015/2239/
 * Description: Integrates with EasyWP to guarantee website performance with caching, monitoring and other services.
 * Version: 0.5.1
 * Author: Namecheap, Inc.
 * Author URI: http://namecheap.com
 * Text Domain: wpnceasywp
 * Domain Path: localization
 *
 */

require WPMU_PLUGIN_DIR.'/wp-nc-easywp/index.php';