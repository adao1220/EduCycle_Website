<?php

if (!defined('ABSPATH')) {
    exit;
}

/*
|--------------------------------------------------------------------------
| Global functions
|--------------------------------------------------------------------------
|
| Here you can insert your global function loaded by composer settings.
|
*/

// Filter the mail sender email
add_filter('wp_mail_from', function ($email) {

    $site_url = get_site_url();
    $re       = '/^https?:\/\/|www./m';
    $domain   = preg_replace($re, '', $site_url);
    $domain   = (strpos($domain, 'easywp.') === false) ? $domain : 'easywp.com';

    return 'wordpress@' . $domain;
});

// Filter the mail sender name
add_filter('wp_mail_from_name', function ($name) {
    return 'EasyWP';
});