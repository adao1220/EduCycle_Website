<?php

namespace WPNCEasyWP\Providers;

use WP_Error;
use WPNCEasyWP\Support\Throttle;
use WPNCEasyWP\WPBones\Support\ServiceProvider;

class WordPressLoginServiceProvider extends ServiceProvider
{

    use Throttle;

    public function register()
    {
        $this->throttleName    = 'x_autologin_';
        $this->throttleTimeout = 30;

        if (isset($_REQUEST['ewp-action'])) {
            if (!is_wp_error($this->grant($_REQUEST['ewp-action']))) {

                do_action('clear_varnish');
                do_action('clear_redis');
                do_action('clear_opcache');

                $this->login();
            }
        }
    }

    protected function grant($redirect)
    {
        $args = [
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'method' => 'GET',
        ];

        $url = rtrim(get_site_url(), '/');

        $redirect .= "&site_url={$url}";

        add_filter('https_ssl_verify', '__return_false');

        $response = wp_remote_request($redirect, $args);

        add_filter('https_ssl_verify', '__return_true');

        $code = wp_remote_retrieve_response_code($response);

        if (200 !== $code) {

            $error = new WP_Error('ewp_bad_status');
            $error->add_data($code);

            return $error;

        }

        return (array) json_decode(wp_remote_retrieve_body($response), true);
    }

    protected function login()
    {
        $redirect = esc_url_raw(self_admin_url());

        if (current_user_can('administrator')) {

            wp_safe_redirect($redirect);

            exit;

        }

        $user = $this->getUserId();

        if ($user) {

            wp_set_auth_cookie($user->ID);

            wp_safe_redirect($redirect);

            exit;
        }
    }

    protected function getUserId()
    {
        // Get the oldest administrator as a fallback.
        $user = get_users([
            'number' => 1,
            'role' => 'administrator',
            'orderby' => 'registered',
            'order' => 'ASC',
        ]);

        return !empty($user[0]->ID) ? $user[0] : false;
    }

}